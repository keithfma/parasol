The unit tests write files into this directory.  This directory must exist.
