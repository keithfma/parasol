#!/bin/bash

service postgresql start
