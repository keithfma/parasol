#!/bin/bash -e
# Installs requirements for PDAL
source ./scripts/ci/common.sh
source ./scripts/ci/docker.sh
source ./scripts/ci/add_deploy_key.sh

